<?php
require 'connect_db.php';
session_start();
$user_name = $_SESSION['user_name'];
$sql = "DELETE FROM user where user_name='$user_name'";//sql语句删除数据库中的用户
$user_folder = "../users/" . $user_name;//用户专属文件夹路径
if (mysqli_query($conn, $sql)){//执行sql语句
    if (is_dir($user_folder)){//检查文件路径是否存在
        $files = array_diff(scandir($user_folder), array('.', '..'));//使用scandir函数来列出文件夹内所有文件，然后再排除掉当前目录'.'和父目录'..'
        foreach ($files as $file){
            (is_dir("$user_folder/$file")) ? deleteFolder("$user_folder/$file") : unlink("$user_folder/$file");
        }
        rmdir($user_folder);
    }
    echo "<script>alert('用户删除成功，点击跳转登录页面');location='./login.php'</script>";
} 
else{
    echo "<script>alert('用户删除失败，点击返回');location='./index.php'</script>";
}
function deleteFolder($user_folder){
    $files = array_diff(scandir($user_folder), array('.', '..'));
    foreach($files as $file){
        (is_dir("$user_folder/$file")) ? deleteFolder("$user_folder/$file") : unlink("$user_folder/$file");//is_dir判断是目录还是文件，是目录则返回true，即执行deleteFolder，是文件则返回false，即执行unlink删除文件
    }
    return rmdir($user_folder);//rmdir函数只能删除空的目录，所以在删除文件夹之前要把里面的文件全部删除
}
